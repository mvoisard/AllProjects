import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

public class FileExample {

	public static void main(String[] args) {
		
		ArrayList<Integer> numbers = new ArrayList<>();
		
		File file = new File("numbers.dat");
		
		if (file.exists()) {
			try {
				ObjectInputStream ois = new ObjectInputStream(new FileInputStream(file));
				numbers = (ArrayList<Integer>) ois.readObject();
				ois.close();
			} catch (Exception e) {
				System.out.println("Could not read in existing account information -- " + 
						"continuing without it.");
			}
		}
		
		System.out.println("Numbers: " + numbers);
		
		numbers.add(1);
		numbers.add(2);
		
		try {
			ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(file));
			oos.writeObject(numbers);
			oos.close();
		} catch (Exception e) {
			System.out.println("Could not write the account information to disk");
		}
	}
}

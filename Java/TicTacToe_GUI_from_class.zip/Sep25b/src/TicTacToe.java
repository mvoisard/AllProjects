import javafx.application.Application;
import javafx.beans.binding.Bindings;
import javafx.beans.property.DoubleProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class TicTacToe extends Application {
//	implements EventHandler<ActionEvent> {
	
	private String symbol = "X";
	
	public static void main(String[] args) {
		
		Application.launch(args);
	}

	@Override
	public void start(Stage primaryStage) throws Exception {
	
		GridPane board = new GridPane();
		
		int count = 1;
		for (int row=0; row<3; row++) {
			for (int col=0; col<3; col++) {
				Button b = new Button(String.valueOf(count++));
				b.setPrefSize(100, 100);
				board.add(b, col, row);
				
//				b.setOnAction(this);
//				b.setOnAction(new SquareEventHandler());
//				b.setOnAction(new EventHandler<ActionEvent>() {
//					@Override
//					public void handle(ActionEvent event) {
//						System.out.println(event);
//						((Button) event.getSource()).setText("X");
//				}});
				
				b.setOnAction(event -> {
//					System.out.println(event);
					if (b.getText().equals("X") || b.getText().equals("O")) {
						return;
					}
					
					b.setText(symbol);
					
					if (symbol.equals("X")) {
						symbol = "O";
					} else {
						symbol = "X";
					}
					
				});
			}
		}
		
		Label msgLabel = new Label("Player 1's turn");
		
		VBox root = new VBox();
		root.getChildren().addAll(board, msgLabel);
		
		Scene scene = new Scene(root, 300, 330);
		
		// optional -- makes buttons resize with the window
		DoubleProperty fontSize = 
				new SimpleDoubleProperty(40);
		fontSize.bind(scene.widthProperty().add(
				scene.heightProperty()).divide(50));
		
		for (Object o: board.getChildren()) {
			((Button) o).prefHeightProperty().bind(
					scene.heightProperty().multiply(.3));
			((Button) o).prefWidthProperty().bind(
					scene.widthProperty().multiply(.33));
			((Button) o).styleProperty().bind(
					Bindings.concat("-fx-font-size: ", 
							fontSize.asString(), ";"));
		}
		
		primaryStage.setScene(scene);
		primaryStage.setTitle("TicTacToe");
		primaryStage.show();
		
	}

//	@Override
//	public void handle(ActionEvent event) {
//		System.out.println(event);
//		((Button) event.getSource()).setText("X");
//	}

}

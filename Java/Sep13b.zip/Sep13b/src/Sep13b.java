
public class Sep13b {

	public static void main(String[] args) {
	
		BankAccount savings = new BankAccount(15);
		
		BankAccount checking = new BankAccount(10);
		
		try {
			savings.withdraw(20);
		} catch (NegativeBalanceException e) {
//			e.printStackTrace();
			savings.deposit(20);
			System.out.println("Transaction rejected: insufficient funds");
		}
		
		try {
			checking.withdraw(20);
		} catch (NegativeBalanceException e) {
//			e.printStackTrace();
			try {
				checking.withdraw(50);
			} catch (NegativeBalanceException e1) {
				// silent catch
			}
			System.out.println("$50 overdraft fee was assessed");
		}
	}

}

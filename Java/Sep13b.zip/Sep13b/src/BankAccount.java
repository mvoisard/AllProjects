
public class BankAccount {
	
	private double balance;
	
	public BankAccount() {
		balance = 0.0;
	}
	
	public BankAccount(double balance) {
		this.balance = balance;
	}
	
	public void withdraw(double amount) 
			throws NegativeBalanceException {
		balance -= amount;
		
		if (balance < 0) {
			throw new NegativeBalanceException("Balance is " + balance);
		}
	}
	
	public void deposit(double amount) {
		balance += amount;
	}

}

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

// Basic idea from here: 
// https://docs.oracle.com/javafx/2/ui_controls/radio-button.htm

public class RadioButtonExample extends Application {

	public static void main(String[] args) {
		Application.launch(args);
	}
	
	@Override
	public void start(Stage primaryStage) throws Exception {
		
		Label message = new Label("One fish");
		
		RadioButton rb1 = new RadioButton("One fish");
		RadioButton rb2 = new RadioButton("Two fish");
		RadioButton rb3 = new RadioButton("Red fish");
		RadioButton rb4 = new RadioButton("Blue fish");
		
		// adding radio buttons to a toggle group makes it 
		// so that only one can be selected at a time
		ToggleGroup group = new ToggleGroup();
		
		RadioButton[] radioButtons = {rb1, rb2, rb3, rb4};
		for (RadioButton rb: radioButtons) {
			rb.setToggleGroup(group);
			rb.setOnAction(e -> {
				message.setText(rb.getText());
			});
		}
		
		rb1.setSelected(true);
		
		VBox root = new VBox();
		root.getChildren().addAll(message, rb1, rb2, rb3, rb4);
		primaryStage.setScene(new Scene(root, 100, 100));
		primaryStage.show();
	}
}

import java.util.ArrayList;
import java.util.Optional;

import javafx.application.Application;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextInputDialog;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class ListViewExample extends Application {

	public static void main(String[] args) {
		Application.launch(args);
	}

	@Override
	public void start(Stage primaryStage) throws Exception {
	
		ArrayList<Student> classroom = new ArrayList<>();
		classroom.add(new Student("Alice"));
		classroom.add(new Student("Bob"));
		classroom.add(new Student("Carol"));
		classroom.add(new Student("Dave"));
		
		Label message = new Label("Selected: ");
		
		ListView<Student> listView = new ListView<>();
		
		ObservableList<Student> items = FXCollections.observableList(
				classroom);
		listView.setItems(items);
		
		listView.getSelectionModel().selectedItemProperty().addListener(
				new ChangeListener<Student>() {
					@Override
					public void changed(
							ObservableValue<? extends Student> observable, 
							Student oldValue, Student newValue) {
						// the newValue is the selected item; this is the one
						// you could do something with, like loan it out, 
						// return it, etc. if this were project 2's code
						message.setText("Selected: " + newValue.toString());
					}});
		
        Button addButton = new Button("Add");
        addButton.setOnAction(e -> {
        	TextInputDialog dialog = new TextInputDialog();
        	dialog.setTitle("New Student Dialog");
        	dialog.setHeaderText(null);
        	dialog.setContentText("Name:");

        	Optional<String> result = dialog.showAndWait();
            result.ifPresent(name -> {
            	Student newStudent = new Student(name);
            	items.add(newStudent);
            });
            
            // Adding an item to the ObservableList adds it to the 
            // underlying ArrayList as well
            System.out.println(classroom);
        });
        
        Button removeButton = new Button("Remove");
        removeButton.setOnAction(e -> {
        	Student selected = listView.getSelectionModel().getSelectedItem();
        	items.remove(selected); // for this to work, you need to override
        	// the hashCode and equals method (Source -> Generate hashCode() 
        	// and equals()
        });
		
		VBox root = new VBox();
		root.getChildren().addAll(message, listView, addButton, removeButton);
		primaryStage.setScene(new Scene(root, 200, 300));
		primaryStage.show();
	}

}

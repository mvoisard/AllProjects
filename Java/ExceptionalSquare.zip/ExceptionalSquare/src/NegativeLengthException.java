public class NegativeLengthException extends Exception {
	private static final long serialVersionUID = 1L;
	
	public NegativeLengthException(String message)
	{
		super(message);
	}
}

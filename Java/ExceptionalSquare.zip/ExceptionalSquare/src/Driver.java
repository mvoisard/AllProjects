import java.util.InputMismatchException;
import java.util.Scanner;

public class Driver {
	public static void main(String[] args) throws NegativeLengthException
	{
		System.out.print("Enter the length of the square's side: ");
		try 
		{
			Scanner reader = new Scanner(System.in);
			double side = reader.nextDouble();
			if (side < 0)
			{
				throw new NegativeLengthException("Negative length: " + side);
			}	
			else
			{
				Square square = new Square();
				System.out.print("Square with ");
				System.out.println(square.toString(side));
				System.out.println("The perimeter of the square is " + square.getPerimeter(side));
				System.out.println("The area of the square is " + square.getArea(side));
			}
		}
		catch (InputMismatchException e)
		{
			System.out.print("Error: you must enter a number");
		}
	}
}

public class Square {
	private double side;
	public Square() throws NegativeLengthException 
	{
		this.side = side;
		if (side < 0)
			throw new NegativeLengthException("Negative length: " + side);
	}
	public String toString(double side)
	{
		String statement = "side = " + side;
		return statement;
	}
	public double getPerimeter(double side)
	{
		double perimeter = 4 * side;
		return perimeter;
	}
	public double getArea(double side)
	{
		double area = side * side;
		return area;
	}
}

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

public class Sep18b extends Application {

	public static void main(String[] args) {
		Application.launch(args);
	}

	@Override
	public void start(Stage primaryStage) throws Exception {
		
		Label l = new Label("Click the Button!!!");
		Button b = new Button("Click Me!");
		
		b.setOnAction(e -> {
			l.setText("Hello, World!");
		});
		
		GridPane root = new GridPane();
		
		root.add(l, 0, 0);
		root.add(b, 0, 1);
		
		primaryStage.setScene(new Scene(root, 300, 200));
		primaryStage.show();
	}

}

public class Rectangle extends Shape {

	public Rectangle() {
		super();
		System.out.println("Making a Rectangle");
	}
	
	public void method1() {
		System.out.println("In Rectangle method1");
	}

	public void method2() {
		System.out.println("In Rectangle method2");
	}
}

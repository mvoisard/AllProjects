public class Shape {
	
	private String color;
	
	public Shape()
	{
		color = "black";
	}
	
	public Shape(String c) {
		color = c;  // or this.color = color;
	}
	
	public void method1() {
		System.out.println("In Shape method1");
	}
	
	public void method2() {
		System.out.println("In Shape method2");
	}
	
	public void method3() {
		System.out.println("In Shape method3");
	}
}

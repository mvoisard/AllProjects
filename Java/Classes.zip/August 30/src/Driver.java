
public class Driver {

	public static void main(String[] args) {
		Shape s1 = new Shape();
		Shape s2 = new Rectangle();      // Polymorphism
		Rectangle r1 = new Rectangle();
		Rectangle r2 = (Rectangle) s2;
		r2.method2();
		s2.method1();
		((Rectangle) s2).method2();
		s2.method3();
		// ((Rectangle) s1).method2();    ClassCastException 
	}
}

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class CheckDivider extends Application {

    private TextField totalTF;
    private TextField tipTF;
    private TextField peopleTF;
    private Label answerLabel;
    
    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) throws Exception {
        
        VBox mainPanel = new VBox();
        
        Label totalLabel = new Label("Total: ");
        totalTF = new TextField();
        
        Label tipLabel = new Label("Tip Percentage: ");
        tipTF = new TextField();
        
        Label peopleLabel = new Label("Number of People: ");
        peopleTF = new TextField();
        
        Label paysLabel = new Label("Each person pays: ");
        answerLabel = new Label("<Enter the above information and press Calculate>");
        
        Button button = new Button("Calculate");
        
        button.setOnAction(e -> { 
    		try
    		{	
    			String total = totalTF.getText();
    			double total2 = Double.parseDouble(text);
    			String tipPercentage = tipTF.getText();
    			double tipPercentage2 = Double.parseDouble(tipPercentage) / 100;
    			String numberOfPeople = peopleTF.getText();
    			int numberOfPeople2 = Double.parseDouble(numberOfPeople);
    			String celsius2 = Double.toString(celsius);
    			celsiusTF.setText(celsius2);
    			double eachPersonPays = (total2 * (1 + tipPercentage2)) / numberOfPeople2;
    			String eachPerson = Double.toString(eachPersonPays);
    			answerLabel.setText("$" + eachPerson);
    		}
    		catch (Exception er)
    		{
    			System.out.println(er.getMessage());
    		}
        });
        
        mainPanel.getChildren().add(totalLabel);
        mainPanel.getChildren().add(totalTF);
        mainPanel.getChildren().add(tipLabel);
        mainPanel.getChildren().add(tipTF);
        mainPanel.getChildren().add(peopleLabel);
        mainPanel.getChildren().add(peopleTF);
        mainPanel.getChildren().add(paysLabel);
        mainPanel.getChildren().add(answerLabel);
        mainPanel.getChildren().add(button);
        
        Scene scene = new Scene(mainPanel, 400, 200);
        primaryStage.setScene(scene);
        primaryStage.setTitle("Check Divider");
        primaryStage.show();

    }

}
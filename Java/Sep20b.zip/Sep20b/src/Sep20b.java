import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class Sep20b extends Application {

	public static void main(String[] args) {
		Application.launch(args);
	}

	@Override
	public void start(Stage primaryStage) throws Exception {
	
		HBox nameBox = new HBox(10);
		Label nameLabel = new Label("Name:");
		TextField nameTF = new TextField();
		nameBox.getChildren().addAll(nameLabel, nameTF);
		
		Button b = new Button("Click Me!");
		Label messageLabel = new Label();
		
		b.setOnAction(e -> {
			String name = nameTF.getText();
			String message = "Hello, " + name + "!";
			messageLabel.setText(message);
		});
		
		VBox root = new VBox(10);
		root.setPadding(new Insets(10, 10, 10, 10));
		root.getChildren().addAll(nameBox, b, messageLabel);
		
		Scene scene = new Scene(root, 300, 110);
		primaryStage.setScene(scene);
		primaryStage.setTitle("GUI Example");
		primaryStage.show();
		
	}

}

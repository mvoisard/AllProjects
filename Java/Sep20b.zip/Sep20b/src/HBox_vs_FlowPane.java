import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class HBox_vs_FlowPane extends Application {

	public static void main(String[] args) {
		Application.launch(args);
	}

	@Override
	public void start(Stage primaryStage) throws Exception {
	
		HBox hBox = new HBox();
		for (int i=0; i<20; i++) {
			Button b = new Button(String.valueOf(i));
			hBox.getChildren().add(b);
		}
		
		FlowPane flowPane = new FlowPane();
		for (int i=0; i<20; i++) {
			Button b = new Button(String.valueOf(i));
			flowPane.getChildren().add(b);
		}
		
		VBox root = new VBox(10);
		root.setPadding(new Insets(10, 10, 10, 10));
		root.getChildren().addAll(hBox, flowPane);
		
		Scene scene = new Scene(root, 300, 110);
		primaryStage.setScene(scene);
		primaryStage.setTitle("GUI Example");
		primaryStage.show();
		
	}

}

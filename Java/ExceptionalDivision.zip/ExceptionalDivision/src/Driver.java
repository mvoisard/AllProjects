import java.util.InputMismatchException;
import java.util.Scanner;

public class Driver {
	public static void main(String[] args)
	{
		int numerator = GetNumerator();
		int denominator = GetDenominator();
		double answer = numerator / denominator;
		System.out.print(numerator + " / " + denominator + " = " + answer);
	}
	
	public static int GetNumerator()
	{
		try 
		{
			System.out.print("What is the numerator? ");
			Scanner reader = new Scanner(System.in);
			int numerator = reader.nextInt();
			return numerator;
		}
		catch (InputMismatchException e)
		{				
			System.out.println("Error: you must enter a whole number");
			GetNumerator();
		}
		return 0;	
	}
	
	public static int GetDenominator()
	{
		try 
		{
			System.out.print("What is the denominator? ");
			Scanner reader = new Scanner(System.in);
			int denominator = reader.nextInt();
			if (denominator == 0)
			{
				System.out.println("Error: the denominator can't be zero");
				GetDenominator();
			}
			return denominator;
		}
		catch (InputMismatchException e)
		{				
			System.out.println("Error: you must enter a whole number");
			GetDenominator();
		}
		return 0;
	}
}

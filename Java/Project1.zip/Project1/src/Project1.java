import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.Collections;

public class Project1
{
	public static void main(String[] args)
	{
		ArrayList<String> titles = new ArrayList<String>();
		ArrayList<String> formats = new ArrayList<String>();
		ArrayList<String> titlesLoaned = new ArrayList<String>();
		ArrayList<String> names = new ArrayList<String>();
		ArrayList<String> dates = new ArrayList<String>();
		boolean Flag = true;
		boolean flag = true;
		boolean flag2 = true;
		boolean flag3 = true;
		boolean flag4 = true;
		while (Flag == true)
		{
		System.out.println("Please enter the numerical code for the action you wish to take. 1 = Insert a new media item, 2 =");
		System.out.println("Mark an item as a loan, 3 = Mark an item as returned, 4 = List the items currently in the collection, ");
		System.out.println("5 = Remove a media item, 6 = Quit ");
		Scanner reader = new Scanner(System.in);
		int number = reader.nextInt();
		if (number == 1)
		{
			System.out.println("Enter the media item's title: ");
			Scanner keyboard = new Scanner(System.in);
			String title = keyboard.nextLine();
			for (int i = 0; i < titles.size(); i++)
			{
			    if (titles.get(i).equals(title))
			    {
			        System.out.print("Error: There is already a record with that title in your collection. Please enter a different title: ");
			        flag = false;
			        Scanner keyboard1 = new Scanner(System.in);
					String title1 = keyboard1.nextLine();
					titles.add(title1);
			    }
			}
			if (flag == true)
				titles.add(title);
			System.out.println("Enter the media item's format: ");
			Scanner input = new Scanner(System.in);
			String format = input.nextLine();
			formats.add(format);
			System.out.print(titles);
		}
		if (number == 2)
		{
			System.out.print("Enter the title of the item to be loaned: ");
			Scanner reader2 = new Scanner(System.in);
			String title = reader2.nextLine();
			for (int i = 0; i < titles.size(); i++)
			{
			    if (titles.get(i).equals(title))
			    {
			    	titlesLoaned.add(title);
			    	flag2 = false;
			    }
			    if (titlesLoaned.get(i).equals(title))
			    	System.out.println("Error. There is already an item with that title on loan.");
			}
			if (flag2 != false)
				System.out.println("There is no record with that title.");
			if (flag3 != false)
				System.out.println("");
			System.out.print("Enter the name of the person the item was loaned to: ");
			Scanner reader3 = new Scanner(System.in);
			String name = reader3.nextLine();
			names.add(name);
			System.out.print("Enter the date the item was loaned: ");
			Scanner reader4 = new Scanner(System.in);
			String date = reader4.nextLine();
			dates.add(date);
		}
		if (number == 3)
		{
			System.out.print("Enter the title of the item to be returned: ");
			Scanner reader2 = new Scanner(System.in);
			String title = reader2.nextLine();
			for (int i = 0; i < titles.size(); i++)
			{
			    if (titles.get(i).equals(title))
			    {
			    	titlesLoaned.remove(title);
			    }
			    if (i == titles.size() - 1)
			    	System.out.print("Error. There is no record that exists with that title in your collection.");
			}
		}
		if (number == 4)
		{
			Collections.sort(titles);
			for (int index1 = 0; index1 < titles.size(); index1++)
				System.out.print("Title: " + titles.get(index1) + " Format: " + formats.get(index1) + "\n");
		}
		if (number == 5)
		{
			System.out.print("Enter the title of the item to be removed: ");
			Scanner reader1 = new Scanner(System.in);
			String title = reader1.nextLine();
			for (int i = 0; i < titles.size(); i++)
			{
			    if (titles.get(i).equals(title))
			    {
			    	titles.remove(title);
			    	flag4 = false;
			    }
			}
			if (flag4 != false)
				System.out.println("Error. That item cannot be removed, as it does not exist in the collection.");
		}
		if (number == 6)
		{
			Flag = false;
			System.out.print("Program terminated.");
		}
		}
	}
}
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class CheckPlease extends Application {

	public static void main(String[] args) {
		Application.launch(args);
	}

	@Override
	public void start(Stage primaryStage) throws Exception {
	
		Label totalLabel = new Label("Total:");
		TextField totalTF = new TextField();
		Label tipPercentageLabel = new Label("Tip Percentage:");
		TextField tipPercentageTF = new TextField();
		Label numberOfPeopleLabel = new Label("Number of People:");
		TextField numberOfPeopleTF = new TextField();
		Label eachPersonPays = new Label("Each person pays:");
		Label instructions = new Label("<Enter the above information and press Calculate>");
		Button b = new Button("Calculate");
		VBox root = new VBox(10);
		root.getChildren().addAll(totalLabel, totalTF, tipPercentageLabel, tipPercentageTF, numberOfPeopleLabel, numberOfPeopleTF, eachPersonPays, instructions, b);
		Scene scene = new Scene(root, 500, 280);
		primaryStage.setScene(scene);
		primaryStage.setTitle("Check Divider");
		primaryStage.show();	
	}
}

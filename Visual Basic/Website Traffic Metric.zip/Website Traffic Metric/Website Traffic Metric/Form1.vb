﻿' Program Name: Website Traffic Metric
' Author:       Max Voisard
' Date:         October 31, 2016
' Purpose:      The Website Traffic Metric program finds the average time in seconds
'               spent on the opening page on the opening page of a company's website,
'               also called website traffic metrics or analytics. This market research
'               is used to improve the effectiveness of the website.

Option Strict On
Public Class Form1

    Private Sub btnVisitorAnalytics_Click(sender As Object, e As EventArgs) Handles btnVisitorAnalytics.Click
        ' The btnVistorAnalytics_Click event accepts and displays up to 12 values 
        ' for seconds on a website and then calculates and displays those values.

        ' Declare and initialize variables.

        Dim strWebsiteSeconds As String
        Dim intWebsiteSeconds As Integer
        Dim dblAverageSeconds As Double
        Dim intTotalSeconds As Integer
        Dim strInputMessage As String = "Enter the number of seconds spent on website: "
        Dim strInputHeading As String = "Seconds on Website"
        Dim strNormalMessage As String = "Enter the number of seconds for person #"
        Dim strNonNumericError As String = "Error - Enter a number for the seconds for person #"
        Dim strNegativeError As String = "Error - Enter a positive number for the seconds for person #"

        ' Declare and initialize loop variables

        Dim strCancelClicked As String = ""
        Dim intMaxNumberOfEntries As Integer = 12
        Dim intNumberOfEntries As Integer = 0

        ' This loop allows the user to enter the number of seconds spent on a website for
        ' up to 12 different people. The program ends once the 12th entry is entered or
        ' if the Cancel button in the input box is selected.

        strWebsiteSeconds = InputBox(strInputMessage & intNumberOfEntries, strInputHeading, " ")

        Do Until intNumberOfEntries > intMaxNumberOfEntries Or strWebsiteSeconds = strCancelClicked

            If IsNumeric(strWebsiteSeconds) Then
                intWebsiteSeconds = Convert.ToInt32(strWebsiteSeconds)
                If intWebsiteSeconds > 0 Then
                    lstSeconds.Items.Add(intWebsiteSeconds)
                    intTotalSeconds += intWebsiteSeconds
                    intNumberOfEntries += 1
                    strInputMessage = strNormalMessage
                Else
                    strInputMessage = strNegativeError
                End If
            Else
                strInputMessage = strNonNumericError
            End If

            If intNumberOfEntries <= intMaxNumberOfEntries Then
                strWebsiteSeconds = InputBox(strInputMessage & intNumberOfEntries, strInputHeading, " ")
            End If

        Loop

        ' Calculates and displays average seconds spent on website
        If intNumberOfEntries > 0 Then
            lblAverageTime.Visible = True
            dblAverageSeconds = intTotalSeconds / intNumberOfEntries
            lblAverageTime.Text = "Average Time Spent: " &
                dblAverageSeconds.ToString("F2") & " seconds"
        Else
            MsgBox("No value for seconds on website entered")
        End If

        ' Disables the Visitor Analytics button
        btnVisitorAnalytics.Enabled = False

    End Sub

End Class

﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblHeading = New System.Windows.Forms.Label()
        Me.btnVisitorAnalytics = New System.Windows.Forms.Button()
        Me.lstSeconds = New System.Windows.Forms.ListBox()
        Me.picWebTraffic = New System.Windows.Forms.PictureBox()
        Me.lblAverageTime = New System.Windows.Forms.Label()
        CType(Me.picWebTraffic, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lblHeading
        '
        Me.lblHeading.AutoSize = True
        Me.lblHeading.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblHeading.Location = New System.Drawing.Point(35, 9)
        Me.lblHeading.Name = "lblHeading"
        Me.lblHeading.Size = New System.Drawing.Size(269, 25)
        Me.lblHeading.TabIndex = 0
        Me.lblHeading.Text = "Website Traffic Estimate"
        '
        'btnVisitorAnalytics
        '
        Me.btnVisitorAnalytics.BackColor = System.Drawing.Color.DarkKhaki
        Me.btnVisitorAnalytics.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnVisitorAnalytics.ForeColor = System.Drawing.Color.DarkGreen
        Me.btnVisitorAnalytics.Location = New System.Drawing.Point(40, 48)
        Me.btnVisitorAnalytics.Name = "btnVisitorAnalytics"
        Me.btnVisitorAnalytics.Size = New System.Drawing.Size(202, 36)
        Me.btnVisitorAnalytics.TabIndex = 1
        Me.btnVisitorAnalytics.Text = "Enter Visitor Analytics"
        Me.btnVisitorAnalytics.UseVisualStyleBackColor = False
        '
        'lstSeconds
        '
        Me.lstSeconds.FormattingEnabled = True
        Me.lstSeconds.Location = New System.Drawing.Point(264, 48)
        Me.lstSeconds.Name = "lstSeconds"
        Me.lstSeconds.Size = New System.Drawing.Size(40, 186)
        Me.lstSeconds.TabIndex = 2
        '
        'picWebTraffic
        '
        Me.picWebTraffic.Image = Global.Website_Traffic_Metric.My.Resources.Resources.FoodAndTraffic
        Me.picWebTraffic.Location = New System.Drawing.Point(1, 289)
        Me.picWebTraffic.Name = "picWebTraffic"
        Me.picWebTraffic.Size = New System.Drawing.Size(338, 128)
        Me.picWebTraffic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picWebTraffic.TabIndex = 3
        Me.picWebTraffic.TabStop = False
        '
        'lblAverageTime
        '
        Me.lblAverageTime.AutoSize = True
        Me.lblAverageTime.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAverageTime.Location = New System.Drawing.Point(12, 266)
        Me.lblAverageTime.Name = "lblAverageTime"
        Me.lblAverageTime.Size = New System.Drawing.Size(286, 18)
        Me.lblAverageTime.TabIndex = 4
        Me.lblAverageTime.Text = "Average Time Spent: XX.XX seconds"
        Me.lblAverageTime.Visible = False
        '
        'Form1
        '
        Me.AcceptButton = Me.btnVisitorAnalytics
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.BurlyWood
        Me.ClientSize = New System.Drawing.Size(323, 413)
        Me.Controls.Add(Me.lblAverageTime)
        Me.Controls.Add(Me.picWebTraffic)
        Me.Controls.Add(Me.lstSeconds)
        Me.Controls.Add(Me.btnVisitorAnalytics)
        Me.Controls.Add(Me.lblHeading)
        Me.Name = "Form1"
        Me.Text = "Form1"
        CType(Me.picWebTraffic, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblHeading As Label
    Friend WithEvents btnVisitorAnalytics As Button
    Friend WithEvents lstSeconds As ListBox
    Friend WithEvents picWebTraffic As PictureBox
    Friend WithEvents lblAverageTime As Label
End Class

﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmTechJobFair
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblTechJobFair = New System.Windows.Forms.Label()
        Me.lblWelcome = New System.Windows.Forms.Label()
        Me.btnViewDetails = New System.Windows.Forms.Button()
        Me.lblDate = New System.Windows.Forms.Label()
        Me.lblLocation = New System.Windows.Forms.Label()
        Me.lblRoom = New System.Windows.Forms.Label()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.picJobFair = New System.Windows.Forms.PictureBox()
        CType(Me.picJobFair, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lblTechJobFair
        '
        Me.lblTechJobFair.AutoSize = True
        Me.lblTechJobFair.Font = New System.Drawing.Font("Tahoma", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTechJobFair.ForeColor = System.Drawing.Color.Green
        Me.lblTechJobFair.Location = New System.Drawing.Point(36, 24)
        Me.lblTechJobFair.Name = "lblTechJobFair"
        Me.lblTechJobFair.Size = New System.Drawing.Size(150, 25)
        Me.lblTechJobFair.TabIndex = 0
        Me.lblTechJobFair.Text = "Tech Job Fair"
        '
        'lblWelcome
        '
        Me.lblWelcome.AutoSize = True
        Me.lblWelcome.Location = New System.Drawing.Point(47, 59)
        Me.lblWelcome.Name = "lblWelcome"
        Me.lblWelcome.Size = New System.Drawing.Size(129, 13)
        Me.lblWelcome.TabIndex = 1
        Me.lblWelcome.Text = "All Students are Welcome"
        '
        'btnViewDetails
        '
        Me.btnViewDetails.BackColor = System.Drawing.Color.Honeydew
        Me.btnViewDetails.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnViewDetails.Location = New System.Drawing.Point(50, 110)
        Me.btnViewDetails.Name = "btnViewDetails"
        Me.btnViewDetails.Size = New System.Drawing.Size(113, 29)
        Me.btnViewDetails.TabIndex = 2
        Me.btnViewDetails.Text = "View Job Fair Details"
        Me.btnViewDetails.UseVisualStyleBackColor = False
        '
        'lblDate
        '
        Me.lblDate.AutoSize = True
        Me.lblDate.Location = New System.Drawing.Point(79, 175)
        Me.lblDate.Name = "lblDate"
        Me.lblDate.Size = New System.Drawing.Size(66, 13)
        Me.lblDate.TabIndex = 3
        Me.lblDate.Text = "May 2, 2016"
        Me.lblDate.Visible = False
        '
        'lblLocation
        '
        Me.lblLocation.AutoSize = True
        Me.lblLocation.Location = New System.Drawing.Point(47, 221)
        Me.lblLocation.Name = "lblLocation"
        Me.lblLocation.Size = New System.Drawing.Size(119, 13)
        Me.lblLocation.TabIndex = 4
        Me.lblLocation.Text = "Located in Lochlan Hall"
        Me.lblLocation.Visible = False
        '
        'lblRoom
        '
        Me.lblRoom.AutoSize = True
        Me.lblRoom.Location = New System.Drawing.Point(79, 245)
        Me.lblRoom.Name = "lblRoom"
        Me.lblRoom.Size = New System.Drawing.Size(56, 13)
        Me.lblRoom.TabIndex = 5
        Me.lblRoom.Text = "Room 101"
        Me.lblRoom.Visible = False
        '
        'btnExit
        '
        Me.btnExit.BackColor = System.Drawing.Color.Honeydew
        Me.btnExit.Location = New System.Drawing.Point(50, 298)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(113, 29)
        Me.btnExit.TabIndex = 6
        Me.btnExit.Text = "Exit Window"
        Me.btnExit.UseVisualStyleBackColor = False
        '
        'picJobFair
        '
        Me.picJobFair.Image = Global.WindowsApplication2.My.Resources.Resources.Fair1
        Me.picJobFair.Location = New System.Drawing.Point(213, 7)
        Me.picJobFair.Name = "picJobFair"
        Me.picJobFair.Size = New System.Drawing.Size(189, 342)
        Me.picJobFair.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picJobFair.TabIndex = 7
        Me.picJobFair.TabStop = False
        '
        'frmTechJobFair
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.BlanchedAlmond
        Me.ClientSize = New System.Drawing.Size(414, 356)
        Me.Controls.Add(Me.picJobFair)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.lblRoom)
        Me.Controls.Add(Me.lblLocation)
        Me.Controls.Add(Me.lblDate)
        Me.Controls.Add(Me.btnViewDetails)
        Me.Controls.Add(Me.lblWelcome)
        Me.Controls.Add(Me.lblTechJobFair)
        Me.Name = "frmTechJobFair"
        Me.Text = "Tech Job Fair"
        CType(Me.picJobFair, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblTechJobFair As Label
    Friend WithEvents lblWelcome As Label
    Friend WithEvents btnViewDetails As Button
    Friend WithEvents lblDate As Label
    Friend WithEvents lblLocation As Label
    Friend WithEvents lblRoom As Label
    Friend WithEvents btnExit As Button
    Friend WithEvents picJobFair As PictureBox
End Class

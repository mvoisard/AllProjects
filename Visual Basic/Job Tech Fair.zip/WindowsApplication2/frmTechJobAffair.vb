﻿Public Class frmTechJobFair
    Private Sub btnViewDetails_Click(sender As Object, e As EventArgs) Handles btnViewDetails.Click
        btnViewDetails.Enabled = False
        lblDate.Visible = True
        lblLocation.Visible = True
        lblRoom.Visible = True
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Close()
    End Sub
End Class
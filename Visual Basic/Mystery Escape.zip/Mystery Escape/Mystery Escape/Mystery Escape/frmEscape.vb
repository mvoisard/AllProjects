﻿' Program Name:               Mystery Escape Application
' Author:                     Max Voisard
' Date:                       November 7, 2016
' Purpose:                    The Mystery Escape application determines the city and game types available and calculates the total team cost.

Option Strict On

Public Class frmEscape

    ' Class Variables
    Private _intOneHour As Integer = 1
    Private _intTwoHour As Integer = 2
    Private _intFourHour As Integer = 4
    Private _strGame1 As String = "Spy in the Study"
    Private _strGame2 As String = "Hidden Cellar"
    Private _strGame3 As String = "Team Building"
    Private _strGame4 As String = "The Encounter"
    Private _strGame5 As String = "Library Larceny"
    Private _strGame6 As String = "Amazing Race"

    Private Sub cboCity_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboCity.SelectedIndexChanged, cboCity.SelectedIndexChanged
        ' This event handler allows the user to enter the city choice and then calls subprocedures to place the game types in the list.
        Dim intCityChoice As Integer

        intCityChoice = cboCity.SelectedIndex
        lstGame.Items.Clear()
        Select Case intCityChoice
            Case 0
                DallasTeam()
            Case 1
                ParisTeam()
            Case 2
                SingaporeTeam()
        End Select
        ' Make items visible in the window
        lblTeam.Visible = True
        txtTeam.Visible = True
        lblSelect.Visible = True
        lstGame.Visible = True
        btnFindCost.Visible = True
        btnClear.Visible = True
        lblGameType.Visible = True
        lblCost.Visible = True
        lblLength.Visible = True
        ' Clear the labels
        lblGameType.Text = ""
        lblCost.Text = ""
        lblLength.Text = ""
        ' Set the focus on number in team text box
        txtTeam.Focus()

    End Sub

    Private Sub DallasTeam()
        ' This procedure fills in the possible game types offered in Dallas
        lstGame.Items.Add(_strGame1)
        lstGame.Items.Add(_strGame2)
        lstGame.Items.Add(_strGame3)

    End Sub

    Private Sub ParisTeam()
        ' This procedure fills in the possible game types offered in Dallas
        lstGame.Items.Add(_strGame4)
        lstGame.Items.Add(_strGame5)

    End Sub

    Private Sub SingaporeTeam()
        ' This procedure fills in the possible game types offered in Dallas
        lstGame.Items.Add(_strGame2)
        lstGame.Items.Add(_strGame3)
        lstGame.Items.Add(_strGame6)
    End Sub

    Private Sub btnFindCost_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnFindCost.Click
        ' This button event handler determines the cost of Mystery Escape Experience
        ' and displays the size of the team, the cost and the length

        Dim intTeamSize As Integer
        Dim blnNumberInTeamIsValid As Boolean = False
        Dim blnGameIsSelected As Boolean = False
        Dim intGameChoice As Integer
        Dim strSelectedTeam As String = ""
        Dim intCityChoice As Integer
        Dim intLength As Integer = 0
        Dim decTotalCost As Decimal

        ' Call a function to ensure the number of people in the team is valid.
        blnNumberInTeamIsValid = ValidateNumberInTeam()
        ' Call a function to ensure the game type was selected
        intGameChoice = ValidateGameSelection(blnGameIsSelected, strSelectedTeam)
        ' If number of people and the game type are valid, calculate the cost
        If (blnNumberInTeamIsValid And blnGameIsSelected) Then
            intTeamSize = Convert.ToInt32(txtTeam.Text)
            intCityChoice = cboCity.SelectedIndex
            Select Case intCityChoice
                Case 0
                    decTotalCost = DallasFindCost(intGameChoice, intTeamSize, intLength)
                Case 1
                    decTotalCost = ParisFindCost(intGameChoice, intTeamSize, intLength)
                Case 2
                    decTotalCost = SingaporeFindCost(intGameChoice, intTeamSize, intLength)
            End Select
            ' Display the cost of the Team
            lblGameType.Text = "Game: " & strSelectedTeam
            lblCost.Text = "Cost: " & decTotalCost.ToString("C")
            lblLength.Text = "Length: " & intLength.ToString() & " hour(s)"
        End If

    End Sub

    Private Function ValidateNumberInTeam() As Boolean
        ' This procedure validates the value entered for the team size

        Dim intTeamSize As Integer
        Dim blnValidityCheck As Boolean = False
        Dim strNumberInTeamMessage As String = "Please enter the number of people in your team (2-6)"
        Dim strMessageBoxTitle As String = "Error"

        Try
            intTeamSize = Convert.ToInt32(txtTeam.Text)
            If intTeamSize >= 2 And intTeamSize <= 6 Then
                blnValidityCheck = True
            Else
                MsgBox(strNumberInTeamMessage, , strMessageBoxTitle)
                txtTeam.Focus()
                txtTeam.Clear()
            End If
        Catch Exception As FormatException
            MsgBox(strNumberInTeamMessage, , strMessageBoxTitle)
            txtTeam.Focus()
            txtTeam.Clear()
        Catch Exception As OverflowException
            MsgBox(strNumberInTeamMessage, , strMessageBoxTitle)
            txtTeam.Focus()
            txtTeam.Clear()
        Catch Exception As SystemException
            MsgBox(strNumberInTeamMessage, , strMessageBoxTitle)
            txtTeam.Focus()
            txtTeam.Clear()
        End Try

        Return blnValidityCheck

    End Function

    Private Function ValidateGameSelection(ByRef blnGame As Boolean, ByRef strGame As String) As Integer
        ' This function ensures the user selected a game type
        Dim intGameType As Integer
        Try
            intGameType = Convert.ToInt32(lstGame.SelectedIndex)
            strGame = lstGame.SelectedItem.ToString()
            blnGame = True
        Catch Exception As SystemException
            ' Detects if a game type is not selected
            MsgBox("Select a Game Type", , "Error")
            blnGame = False
        End Try
        Return intGameType

    End Function

    Private Function DallasFindCost(ByVal intGame As Integer, ByVal intTeam As Integer, ByRef intTime As Integer) As Decimal
        ' This function calculates the cost of the team in Singapore

        Dim decTeamCost As Decimal
        Dim decFinalCost As Decimal
        Dim decDallasGame1 As Decimal = 32D
        Dim decDallasGame2 As Decimal = 39D
        Dim decDallasGame3 As Decimal = 55D

        Select Case intGame
            Case 0
                decTeamCost = decDallasGame1
                intTime = _intOneHour
            Case 1
                decTeamCost = decDallasGame2
                intTime = _intOneHour
            Case 2
                decTeamCost = decDallasGame3
                intTime = _intTwoHour
        End Select
        decFinalCost = decTeamCost * intTeam
        Return decFinalCost

    End Function

    Private Function ParisFindCost(ByVal intGame As Integer, ByVal intTeam As Integer, ByRef intTime As Integer) As Decimal
        ' This function calculates the cost of the team in Singapore

        Dim decTeamCost As Decimal
        Dim decFinalCost As Decimal
        Dim decParisGame4 As Decimal = 38D
        Dim decParisGame5 As Decimal = 45D

        Select Case intGame
            Case 0
                decTeamCost = decParisGame4
                intTime = _intOneHour
            Case 1
                decTeamCost = decParisGame5
                intTime = _intOneHour
        End Select
        decFinalCost = decTeamCost * intTeam
        Return decFinalCost

    End Function

    Private Function SingaporeFindCost(ByVal intGame As Integer, ByVal intTeam As Integer, ByRef intTime As Integer) As Decimal
        ' This function calculates the cost of the team in Singapore

        Dim decTeamCost As Decimal
        Dim decFinalCost As Decimal
        Dim decSingaporeGame2 As Decimal = 45D
        Dim decSingaporeGame3 As Decimal = 65D
        Dim decSingaporeGame6 As Decimal = 75D

        Select Case intGame
            Case 0
                decTeamCost = decSingaporeGame2
                intTime = _intOneHour
            Case 1
                decTeamCost = decSingaporeGame3
                intTime = _intTwoHour
            Case 2
                decTeamCost = decSingaporeGame6
                intTime = _intFourHour
        End Select
        decFinalCost = decTeamCost * intTeam
        Return decFinalCost

    End Function

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        ' This event handler clears the form and resets the form for reuse when the user clicks the Clear button.

        cboCity.Text = "Select City Location"
        txtTeam.Clear()
        lstGame.Items.Clear()
        lblGameType.Text = ""
        lblCost.Text = ""
        lblLength.Text = ""
        lblTeam.Visible = False
        txtTeam.Visible = False
        lblSelect.Visible = False
        lstGame.Visible = False
        btnFindCost.Visible = False
        btnClear.Visible = False
        lblGameType.Visible = False
        lblCost.Visible = False
        lblLength.Visible = False

    End Sub

    Private Sub frmEscape_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' Hold the splash screen for 3 seconds

        Threading.Thread.Sleep(5000)
    End Sub
End Class

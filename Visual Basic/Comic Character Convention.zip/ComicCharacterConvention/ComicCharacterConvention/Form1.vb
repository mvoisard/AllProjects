﻿' Program Name: Comic Character Convention
' Author:       Max Voisard
' Date:         October 17, 2016
' Purpose:      This Windows application computes the registation cost
'               of attending a Comic Character Convention.
Public Class Form1
    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click
        ' The btnCalculate event handler calculates the registration cost
        ' at the convention based on badge type and preview night.

        ' Declaration Section
        Dim intGroupSize As Integer
        Dim intBadgeTypeCost As Integer
        Dim intRegistrationCost As Integer
        Dim intPreviewNightSelected As Integer
        Dim intPreviewNight As Integer = 59
        Dim intSuperheroCost As Integer = 330
        Dim intAutographCost As Integer = 255
        Dim intConventionCost As Integer = 199

        ' Did user enter a numeric value?
        If IsNumeric(txtGroupSize.Text) Then
            intGroupSize = Convert.ToDecimal(txtGroupSize.Text)

            ' Is group size greater than zero?
            If intGroupSize > 0 And intGroupSize <= 20 Then
                ' Determine cost per badge type
                If radSuperhero.Checked Then
                    intBadgeTypeCost = intSuperheroCost
                ElseIf radAutographs.Checked Then
                    intBadgeTypeCost = intAutographCost
                ElseIf radConvention.Checked Then
                    intBadgeTypeCost = intConventionCost
                End If
                ' Is the preview night radio button selected so it affects the cost?
                If radPreviewNight.Checked Then
                    intPreviewNightSelected = intPreviewNight
                End If

                ' Calculate and display the registration cost
                intRegistrationCost = intGroupSize * (intBadgeTypeCost + intPreviewNightSelected)
                lblRegistrationCost.Text = intRegistrationCost.ToString("C")
                Else
                    ' Display error message if user entered a negative value
                    MsgBox("You entered " & intGroupSize.ToString() & ". Enter a positive number that is 20 or less.", , "Input Error")
                txtGroupSize.Text = ""
                txtGroupSize.Focus()
            End If
        Else
            ' Display error message if user entered a nonnumeric value
            MsgBox("Enter a number for the number of people in your group.", , "Input Error")
            txtGroupSize.Text = ""
            txtGroupSize.Focus()
        End If
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        ' This event handler is executed when the user taps or clicks the Clear button. It
        ' clears the group size text box and the Registration Cost label, resets the radio
        ' buttons with Superhero selected, and sets the focus to the group size text box.

        txtGroupSize.Clear()
        lblRegistrationCost.Text = ""
        radSuperhero.Checked = True
        radAutographs.Checked = False
        radConvention.Checked = False
        radPreviewNight.Checked = False
        txtGroupSize.Focus()
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' This event handler is executed when the form is loaded at the start of 
        ' the program. It sets the focus to the group size text box and 
        ' clears the registration cost label.

        txtGroupSize.Focus()
        lblRegistrationCost.Text = ""
    End Sub
End Class

﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.picBook = New System.Windows.Forms.PictureBox()
        Me.lblHeading = New System.Windows.Forms.Label()
        Me.lstScores = New System.Windows.Forms.ListBox()
        Me.lblSemesterGrade = New System.Windows.Forms.Label()
        Me.btnEnterScores = New System.Windows.Forms.Button()
        CType(Me.picBook, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'picBook
        '
        Me.picBook.Image = Global.Semester_Averages.My.Resources.Resources.book_red
        Me.picBook.Location = New System.Drawing.Point(2, 0)
        Me.picBook.Name = "picBook"
        Me.picBook.Size = New System.Drawing.Size(110, 100)
        Me.picBook.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picBook.TabIndex = 0
        Me.picBook.TabStop = False
        '
        'lblHeading
        '
        Me.lblHeading.AutoSize = True
        Me.lblHeading.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblHeading.Location = New System.Drawing.Point(133, 44)
        Me.lblHeading.Name = "lblHeading"
        Me.lblHeading.Size = New System.Drawing.Size(175, 24)
        Me.lblHeading.TabIndex = 1
        Me.lblHeading.Text = "Semester Averages"
        '
        'lstScores
        '
        Me.lstScores.FormattingEnabled = True
        Me.lstScores.Location = New System.Drawing.Point(118, 92)
        Me.lstScores.Name = "lstScores"
        Me.lstScores.Size = New System.Drawing.Size(159, 134)
        Me.lstScores.TabIndex = 2
        '
        'lblSemesterGrade
        '
        Me.lblSemesterGrade.AutoSize = True
        Me.lblSemesterGrade.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSemesterGrade.Location = New System.Drawing.Point(103, 285)
        Me.lblSemesterGrade.Name = "lblSemesterGrade"
        Me.lblSemesterGrade.Size = New System.Drawing.Size(133, 16)
        Me.lblSemesterGrade.TabIndex = 3
        Me.lblSemesterGrade.Text = "Final Average: XXX.X"
        '
        'btnEnterScores
        '
        Me.btnEnterScores.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnEnterScores.Location = New System.Drawing.Point(119, 232)
        Me.btnEnterScores.Name = "btnEnterScores"
        Me.btnEnterScores.Size = New System.Drawing.Size(158, 26)
        Me.btnEnterScores.TabIndex = 4
        Me.btnEnterScores.Text = "Enter Scores"
        Me.btnEnterScores.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(334, 330)
        Me.Controls.Add(Me.btnEnterScores)
        Me.Controls.Add(Me.lblSemesterGrade)
        Me.Controls.Add(Me.lstScores)
        Me.Controls.Add(Me.lblHeading)
        Me.Controls.Add(Me.picBook)
        Me.Name = "Form1"
        Me.Text = "Final Averages for Semester"
        CType(Me.picBook, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents picBook As PictureBox
    Friend WithEvents lblHeading As Label
    Friend WithEvents lstScores As ListBox
    Friend WithEvents lblSemesterGrade As Label
    Friend WithEvents btnEnterScores As Button
End Class

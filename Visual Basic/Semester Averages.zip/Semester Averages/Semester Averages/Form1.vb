﻿' Program Name: Final Averages for Semester
' Author:       Max Voisard
' Date:         November 14, 2016
' Purpose:      This Windows application allows an instructor to enter 13 project scores from
'               a course and compute one student's grade for the semester. The appplication
'               displays the student's final average for the semester when the two lowest scores
'               are removed from the average. The 11 grades in sorted order and the final average
'               are written to a text file named grades.txt on the USB drive (E:).

Public Class Form1

    Private Sub btnEnterScores_Click(sender As Object, e As EventArgs) Handles btnEnterScores.Click

        ' Initializing and declaring class-level variables
        Dim decTotal As Decimal = 0D
        Dim decAverage As Decimal
        Dim intMaxNumberOfEntries = 12
        Dim decGradeEntries(intMaxNumberOfEntries) As Decimal
        Dim intNumberOfGradeEntries As Integer
        Dim strInputHeading As String = "Project Scores: "
        Dim strInputMessage As String = "Enter Grade: "
        Dim strNonNumericError As String = "Error - Enter a number: "
        Dim strNegativeError As String = "Error - Enter a positive number: "
        Dim strCancelClicked As String = ""

        ' For loop for entries 0-12, asking for input and adding numbers
        For intNumberOfGradeEntries = 0 To (decGradeEntries.Length - 1)
            decTotal += decGradeEntries(intNumberOfGradeEntries)
            decGradeEntries(intNumberOfGradeEntries) = CInt(InputBox("Enter Grade #" & intNumberOfGradeEntries + 1, strInputHeading))

            ' Top-controlled Do Until loop inside the For Loop for valid test score
            Do Until decGradeEntries(intNumberOfGradeEntries) >= 0 And decGradeEntries(intNumberOfGradeEntries) <= 100
                MsgBox("Invalid value.", , "Error")
                decGradeEntries(intNumberOfGradeEntries) = CInt(InputBox("Enter Grade #" & intNumberOfGradeEntries + 1, strInputHeading))
            Loop
        Next

        ' Sorting values from lowest to highest and adding entries in For loop
        Array.Sort(decGradeEntries)
        For intNumberOfGradeEntries = 2 To (decGradeEntries.Length - 1)
            decTotal += decGradeEntries(intNumberOfGradeEntries)
        Next

        ' If-else statement for calculating average
        If intNumberOfGradeEntries > 1 Then
            decAverage = decTotal / (intNumberOfGradeEntries - 2)
            lblSemesterGrade.Text = "Final Average: " & decAverage.ToString("F1")
        Else

        End If

        ' Declaring variables to be written to text file
        Dim objWriter As New IO.StreamWriter("C:\Users\mvoisard\Desktop\grades.txt")
        Dim intAdd As Integer = 0
        Dim strFileError As String = "Could not find text file!"
        If IO.File.Exists("C:\Users\mvoisard\Desktop\grades.txt") Then
            ' Starting at third lowest scores to highest so it eliminates the bottom two
            For intAdd = 2 To (decGradeEntries.Length - 1)
                objWriter.WriteLine(decGradeEntries(intAdd))
            Next

            ' Writes the average of the student
            objWriter.WriteLine(lblSemesterGrade.Text)
            'objWriter.WriteLine("Final Average: " & decAverage.ToString("F1"))

        Else
            MsgBox("Could not find text file!")
        End If
        objWriter.Close()

    End Sub
End Class

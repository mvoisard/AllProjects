﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmVeggieSpecials
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblVegetarianSpecials = New System.Windows.Forms.Label()
        Me.btnFalafel = New System.Windows.Forms.Button()
        Me.btnSelectMeal = New System.Windows.Forms.Button()
        Me.btnVeggieBurger = New System.Windows.Forms.Button()
        Me.lblInstructions = New System.Windows.Forms.Label()
        Me.lblConfirmation = New System.Windows.Forms.Label()
        Me.btnExitWindow = New System.Windows.Forms.Button()
        Me.picVeggieBurger = New System.Windows.Forms.PictureBox()
        Me.picFalafel = New System.Windows.Forms.PictureBox()
        CType(Me.picVeggieBurger, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picFalafel, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lblVegetarianSpecials
        '
        Me.lblVegetarianSpecials.AutoSize = True
        Me.lblVegetarianSpecials.Font = New System.Drawing.Font("Tahoma", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblVegetarianSpecials.Location = New System.Drawing.Point(99, 22)
        Me.lblVegetarianSpecials.Name = "lblVegetarianSpecials"
        Me.lblVegetarianSpecials.Size = New System.Drawing.Size(217, 25)
        Me.lblVegetarianSpecials.TabIndex = 0
        Me.lblVegetarianSpecials.Text = "Vegetarian Specials"
        '
        'btnFalafel
        '
        Me.btnFalafel.Location = New System.Drawing.Point(64, 238)
        Me.btnFalafel.Name = "btnFalafel"
        Me.btnFalafel.Size = New System.Drawing.Size(85, 23)
        Me.btnFalafel.TabIndex = 3
        Me.btnFalafel.Text = "Falafel"
        Me.btnFalafel.UseVisualStyleBackColor = True
        '
        'btnSelectMeal
        '
        Me.btnSelectMeal.Location = New System.Drawing.Point(168, 238)
        Me.btnSelectMeal.Name = "btnSelectMeal"
        Me.btnSelectMeal.Size = New System.Drawing.Size(85, 23)
        Me.btnSelectMeal.TabIndex = 4
        Me.btnSelectMeal.Text = "Select Meal"
        Me.btnSelectMeal.UseVisualStyleBackColor = True
        '
        'btnVeggieBurger
        '
        Me.btnVeggieBurger.Location = New System.Drawing.Point(272, 238)
        Me.btnVeggieBurger.Name = "btnVeggieBurger"
        Me.btnVeggieBurger.Size = New System.Drawing.Size(85, 23)
        Me.btnVeggieBurger.TabIndex = 6
        Me.btnVeggieBurger.Text = "Veggie Burger"
        Me.btnVeggieBurger.UseVisualStyleBackColor = True
        '
        'lblInstructions
        '
        Me.lblInstructions.AutoSize = True
        Me.lblInstructions.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblInstructions.Location = New System.Drawing.Point(59, 273)
        Me.lblInstructions.Name = "lblInstructions"
        Me.lblInstructions.Size = New System.Drawing.Size(297, 14)
        Me.lblInstructions.TabIndex = 7
        Me.lblInstructions.Text = "Choose a meal and then click the Select Meal button"
        '
        'lblConfirmation
        '
        Me.lblConfirmation.AutoSize = True
        Me.lblConfirmation.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblConfirmation.Location = New System.Drawing.Point(125, 296)
        Me.lblConfirmation.Name = "lblConfirmation"
        Me.lblConfirmation.Size = New System.Drawing.Size(165, 14)
        Me.lblConfirmation.TabIndex = 8
        Me.lblConfirmation.Text = "Enjoy your vegetarian special"
        '
        'btnExitWindow
        '
        Me.btnExitWindow.Location = New System.Drawing.Point(168, 321)
        Me.btnExitWindow.Name = "btnExitWindow"
        Me.btnExitWindow.Size = New System.Drawing.Size(75, 23)
        Me.btnExitWindow.TabIndex = 9
        Me.btnExitWindow.Text = "Exit Window"
        Me.btnExitWindow.UseVisualStyleBackColor = True
        '
        'picVeggieBurger
        '
        Me.picVeggieBurger.Image = Global.WindowsApplication1.My.Resources.Resources.VeggieBurger
        Me.picVeggieBurger.Location = New System.Drawing.Point(216, 75)
        Me.picVeggieBurger.Name = "picVeggieBurger"
        Me.picVeggieBurger.Size = New System.Drawing.Size(185, 150)
        Me.picVeggieBurger.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picVeggieBurger.TabIndex = 2
        Me.picVeggieBurger.TabStop = False
        Me.picVeggieBurger.Visible = False
        '
        'picFalafel
        '
        Me.picFalafel.Image = Global.WindowsApplication1.My.Resources.Resources.Falafel
        Me.picFalafel.Location = New System.Drawing.Point(13, 73)
        Me.picFalafel.Name = "picFalafel"
        Me.picFalafel.Size = New System.Drawing.Size(185, 150)
        Me.picFalafel.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picFalafel.TabIndex = 1
        Me.picFalafel.TabStop = False
        Me.picFalafel.Visible = False
        '
        'frmVeggieSpecials
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Khaki
        Me.ClientSize = New System.Drawing.Size(414, 356)
        Me.Controls.Add(Me.btnExitWindow)
        Me.Controls.Add(Me.lblConfirmation)
        Me.Controls.Add(Me.lblInstructions)
        Me.Controls.Add(Me.btnVeggieBurger)
        Me.Controls.Add(Me.btnSelectMeal)
        Me.Controls.Add(Me.btnFalafel)
        Me.Controls.Add(Me.picVeggieBurger)
        Me.Controls.Add(Me.picFalafel)
        Me.Controls.Add(Me.lblVegetarianSpecials)
        Me.Name = "frmVeggieSpecials"
        Me.Text = "Veggie Specials"
        CType(Me.picVeggieBurger, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picFalafel, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblVegetarianSpecials As Label
    Friend WithEvents picFalafel As PictureBox
    Friend WithEvents picVeggieBurger As PictureBox
    Friend WithEvents btnFalafel As Button
    Friend WithEvents btnSelectMeal As Button
    Friend WithEvents btnVeggieBurger As Button
    Friend WithEvents lblInstructions As Label
    Friend WithEvents lblConfirmation As Label
    Friend WithEvents btnExitWindow As Button
End Class

﻿'Program Name: Vegetarian Specialss
'Developer: Max Voisard
'Date: September 26, 2016
'Class: Visual Basic Program 001FS
'Purpose: This application displays two vegetarian specials (falafel and veggie burger). The user can select which one.
Public Class frmVeggieSpecials
    Private Sub btnFalafel_Click(sender As Object, e As EventArgs) Handles btnFalafel.Click
        'This code is executed when the user taps or clicks the Falafel button.
        'It displays the Falafel picture, hides the Veggie Burger picture, and
        'enables the Select Menu button.
        picFalafel.Visible = True
        picVeggieBurger.Visible = False
        btnSelectMeal.Enabled = True 'Enable button

    End Sub

    Private Sub btnSelectMeal_Click(sender As Object, e As EventArgs) Handles btnSelectMeal.Click
        'This code is executed when the user taps or clicks the Select Meal button.
        'It disabes the Falafel button, the Select Meal button, and the Veggie
        'Burger button. It hides the Instructions label, displays the Confirmation
        'label, and enables the Exit Window button.
        btnFalafel.Enabled = False
        btnSelectMeal.Enabled = False
        btnVeggieBurger.Enabled = False
        lblInstructions.Visible = False
        lblConfirmation.Visible = False
        btnExitWindow.Enabled = True
    End Sub

    Private Sub btnVeggieBurger_Click(sender As Object, e As EventArgs) Handles btnVeggieBurger.Click
        picVeggieBurger.Visible = True
        picFalafel.Visible = False
        btnSelectMeal.Enabled = True
        'This code is executed when the user taps or clicks the Veggie Burger button.
        'It displays the Veggie Burger picture, hides the Falafel picture, and
        'enables the Select Menu button.
    End Sub

    Private Sub btnExitWindow_Click(sender As Object, e As EventArgs) Handles btnExitWindow.Click
        Close()
    End Sub
End Class

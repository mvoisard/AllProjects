﻿' Title:    Top Ten Technology Job Database
' Author:   Max Voisard
' Date:     November 28, 2016
' Purpose:  This Windows application opens an Access database that contains information about
'           the current top ten technology jobs, their ranking placement, and the median salary.

Public Class Form1
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'TechJobsDataSet.TechJobs' table. You can move, or remove it, as needed.
        Me.TechJobsTableAdapter.Fill(Me.TechJobsDataSet.TechJobs)

    End Sub

    Private Sub TechJobsBindingNavigatorSaveItem_Click_1(sender As Object, e As EventArgs) Handles TechJobsBindingNavigatorSaveItem.Click
        Me.Validate()
        Me.TechJobsBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.TechJobsDataSet)

    End Sub

    Private Sub TechJobsBindingNavigatorSaveItem_Click(sender As Object, e As EventArgs)

        Dim strSql As String = "SELECT * FROM TechJobs"

        ' strPath provides the database type and path of the Art database
        Dim strPath As String = "Provider=Microsoft.ACE.OLEDB.12.0 ;" & "Data Source=e:\TechJobs.accdb"
        Dim odaTechJobs As New OleDb.OleDbDataAdapter(strSql, strPath)
        Dim datValue As New DataTable

        ' The DataTable name datValue is filled with the table data
        odaTechJobs.Fill(datValue)
        ' The connection to the database is disconnected
        odaTechJobs.Dispose()

    End Sub
End Class
﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Dim Job_NameLabel As System.Windows.Forms.Label
        Dim Median_SalaryLabel As System.Windows.Forms.Label
        Dim Job_NameLabel1 As System.Windows.Forms.Label
        Me.picJobs = New System.Windows.Forms.PictureBox()
        Me.lblHeading = New System.Windows.Forms.Label()
        Me.lblPlacement = New System.Windows.Forms.Label()
        Me.lblJobName = New System.Windows.Forms.Label()
        Me.lblMedianSalary = New System.Windows.Forms.Label()
        Me.TechJobsDataSet = New Top_Ten_Technology_Job_Database.TechJobsDataSet()
        Me.TechJobsBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.TechJobsTableAdapter = New Top_Ten_Technology_Job_Database.TechJobsDataSetTableAdapters.TechJobsTableAdapter()
        Me.TableAdapterManager = New Top_Ten_Technology_Job_Database.TechJobsDataSetTableAdapters.TableAdapterManager()
        Me.TechJobsBindingNavigator = New System.Windows.Forms.BindingNavigator(Me.components)
        Me.BindingNavigatorAddNewItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorCountItem = New System.Windows.Forms.ToolStripLabel()
        Me.BindingNavigatorDeleteItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMoveFirstItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMovePreviousItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorPositionItem = New System.Windows.Forms.ToolStripTextBox()
        Me.BindingNavigatorSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorMoveNextItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMoveLastItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.TechJobsBindingNavigatorSaveItem = New System.Windows.Forms.ToolStripButton()
        Me.txtPlacement = New System.Windows.Forms.TextBox()
        Me.txtMedianSalary = New System.Windows.Forms.TextBox()
        Me.cboJobName = New System.Windows.Forms.ComboBox()
        Job_NameLabel = New System.Windows.Forms.Label()
        Median_SalaryLabel = New System.Windows.Forms.Label()
        Job_NameLabel1 = New System.Windows.Forms.Label()
        CType(Me.picJobs, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TechJobsDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TechJobsBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TechJobsBindingNavigator, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TechJobsBindingNavigator.SuspendLayout()
        Me.SuspendLayout()
        '
        'picJobs
        '
        Me.picJobs.Image = Global.Top_Ten_Technology_Job_Database.My.Resources.Resources.Jobs
        Me.picJobs.Location = New System.Drawing.Point(2, 25)
        Me.picJobs.Name = "picJobs"
        Me.picJobs.Size = New System.Drawing.Size(207, 242)
        Me.picJobs.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picJobs.TabIndex = 0
        Me.picJobs.TabStop = False
        '
        'lblHeading
        '
        Me.lblHeading.AutoSize = True
        Me.lblHeading.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblHeading.ForeColor = System.Drawing.Color.White
        Me.lblHeading.Location = New System.Drawing.Point(292, 25)
        Me.lblHeading.Name = "lblHeading"
        Me.lblHeading.Size = New System.Drawing.Size(264, 24)
        Me.lblHeading.TabIndex = 1
        Me.lblHeading.Text = "Technology Job Opportunities"
        '
        'lblPlacement
        '
        Me.lblPlacement.AutoSize = True
        Me.lblPlacement.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPlacement.ForeColor = System.Drawing.Color.White
        Me.lblPlacement.Location = New System.Drawing.Point(234, 84)
        Me.lblPlacement.Name = "lblPlacement"
        Me.lblPlacement.Size = New System.Drawing.Size(104, 24)
        Me.lblPlacement.TabIndex = 2
        Me.lblPlacement.Text = "Placement:"
        '
        'lblJobName
        '
        Me.lblJobName.AutoSize = True
        Me.lblJobName.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblJobName.ForeColor = System.Drawing.Color.White
        Me.lblJobName.Location = New System.Drawing.Point(234, 141)
        Me.lblJobName.Name = "lblJobName"
        Me.lblJobName.Size = New System.Drawing.Size(102, 24)
        Me.lblJobName.TabIndex = 3
        Me.lblJobName.Text = "Job Name:"
        '
        'lblMedianSalary
        '
        Me.lblMedianSalary.AutoSize = True
        Me.lblMedianSalary.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblMedianSalary.ForeColor = System.Drawing.Color.White
        Me.lblMedianSalary.Location = New System.Drawing.Point(234, 193)
        Me.lblMedianSalary.Name = "lblMedianSalary"
        Me.lblMedianSalary.Size = New System.Drawing.Size(134, 24)
        Me.lblMedianSalary.TabIndex = 4
        Me.lblMedianSalary.Text = "Median Salary:"
        '
        'TechJobsDataSet
        '
        Me.TechJobsDataSet.DataSetName = "TechJobsDataSet"
        Me.TechJobsDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'TechJobsBindingSource
        '
        Me.TechJobsBindingSource.DataMember = "TechJobs"
        Me.TechJobsBindingSource.DataSource = Me.TechJobsDataSet
        '
        'TechJobsTableAdapter
        '
        Me.TechJobsTableAdapter.ClearBeforeFill = True
        '
        'TableAdapterManager
        '
        Me.TableAdapterManager.BackupDataSetBeforeUpdate = False
        Me.TableAdapterManager.TechJobsTableAdapter = Me.TechJobsTableAdapter
        Me.TableAdapterManager.UpdateOrder = Top_Ten_Technology_Job_Database.TechJobsDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete
        '
        'TechJobsBindingNavigator
        '
        Me.TechJobsBindingNavigator.AddNewItem = Me.BindingNavigatorAddNewItem
        Me.TechJobsBindingNavigator.BindingSource = Me.TechJobsBindingSource
        Me.TechJobsBindingNavigator.CountItem = Me.BindingNavigatorCountItem
        Me.TechJobsBindingNavigator.DeleteItem = Me.BindingNavigatorDeleteItem
        Me.TechJobsBindingNavigator.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BindingNavigatorMoveFirstItem, Me.BindingNavigatorMovePreviousItem, Me.BindingNavigatorSeparator, Me.BindingNavigatorPositionItem, Me.BindingNavigatorCountItem, Me.BindingNavigatorSeparator1, Me.BindingNavigatorMoveNextItem, Me.BindingNavigatorMoveLastItem, Me.BindingNavigatorSeparator2, Me.BindingNavigatorAddNewItem, Me.BindingNavigatorDeleteItem, Me.TechJobsBindingNavigatorSaveItem})
        Me.TechJobsBindingNavigator.Location = New System.Drawing.Point(0, 0)
        Me.TechJobsBindingNavigator.MoveFirstItem = Me.BindingNavigatorMoveFirstItem
        Me.TechJobsBindingNavigator.MoveLastItem = Me.BindingNavigatorMoveLastItem
        Me.TechJobsBindingNavigator.MoveNextItem = Me.BindingNavigatorMoveNextItem
        Me.TechJobsBindingNavigator.MovePreviousItem = Me.BindingNavigatorMovePreviousItem
        Me.TechJobsBindingNavigator.Name = "TechJobsBindingNavigator"
        Me.TechJobsBindingNavigator.PositionItem = Me.BindingNavigatorPositionItem
        Me.TechJobsBindingNavigator.Size = New System.Drawing.Size(747, 25)
        Me.TechJobsBindingNavigator.TabIndex = 8
        Me.TechJobsBindingNavigator.Text = "BindingNavigator1"
        '
        'BindingNavigatorAddNewItem
        '
        Me.BindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorAddNewItem.Image = CType(resources.GetObject("BindingNavigatorAddNewItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorAddNewItem.Name = "BindingNavigatorAddNewItem"
        Me.BindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorAddNewItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorAddNewItem.Text = "Add new"
        '
        'BindingNavigatorCountItem
        '
        Me.BindingNavigatorCountItem.Name = "BindingNavigatorCountItem"
        Me.BindingNavigatorCountItem.Size = New System.Drawing.Size(35, 22)
        Me.BindingNavigatorCountItem.Text = "of {0}"
        Me.BindingNavigatorCountItem.ToolTipText = "Total number of items"
        '
        'BindingNavigatorDeleteItem
        '
        Me.BindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorDeleteItem.Image = CType(resources.GetObject("BindingNavigatorDeleteItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorDeleteItem.Name = "BindingNavigatorDeleteItem"
        Me.BindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorDeleteItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorDeleteItem.Text = "Delete"
        '
        'BindingNavigatorMoveFirstItem
        '
        Me.BindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveFirstItem.Image = CType(resources.GetObject("BindingNavigatorMoveFirstItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveFirstItem.Name = "BindingNavigatorMoveFirstItem"
        Me.BindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveFirstItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveFirstItem.Text = "Move first"
        '
        'BindingNavigatorMovePreviousItem
        '
        Me.BindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMovePreviousItem.Image = CType(resources.GetObject("BindingNavigatorMovePreviousItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMovePreviousItem.Name = "BindingNavigatorMovePreviousItem"
        Me.BindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMovePreviousItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMovePreviousItem.Text = "Move previous"
        '
        'BindingNavigatorSeparator
        '
        Me.BindingNavigatorSeparator.Name = "BindingNavigatorSeparator"
        Me.BindingNavigatorSeparator.Size = New System.Drawing.Size(6, 25)
        '
        'BindingNavigatorPositionItem
        '
        Me.BindingNavigatorPositionItem.AccessibleName = "Position"
        Me.BindingNavigatorPositionItem.AutoSize = False
        Me.BindingNavigatorPositionItem.Name = "BindingNavigatorPositionItem"
        Me.BindingNavigatorPositionItem.Size = New System.Drawing.Size(50, 23)
        Me.BindingNavigatorPositionItem.Text = "0"
        Me.BindingNavigatorPositionItem.ToolTipText = "Current position"
        '
        'BindingNavigatorSeparator1
        '
        Me.BindingNavigatorSeparator1.Name = "BindingNavigatorSeparator1"
        Me.BindingNavigatorSeparator1.Size = New System.Drawing.Size(6, 25)
        '
        'BindingNavigatorMoveNextItem
        '
        Me.BindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveNextItem.Image = CType(resources.GetObject("BindingNavigatorMoveNextItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveNextItem.Name = "BindingNavigatorMoveNextItem"
        Me.BindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveNextItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveNextItem.Text = "Move next"
        '
        'BindingNavigatorMoveLastItem
        '
        Me.BindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveLastItem.Image = CType(resources.GetObject("BindingNavigatorMoveLastItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveLastItem.Name = "BindingNavigatorMoveLastItem"
        Me.BindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveLastItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveLastItem.Text = "Move last"
        '
        'BindingNavigatorSeparator2
        '
        Me.BindingNavigatorSeparator2.Name = "BindingNavigatorSeparator2"
        Me.BindingNavigatorSeparator2.Size = New System.Drawing.Size(6, 25)
        '
        'TechJobsBindingNavigatorSaveItem
        '
        Me.TechJobsBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.TechJobsBindingNavigatorSaveItem.Image = CType(resources.GetObject("TechJobsBindingNavigatorSaveItem.Image"), System.Drawing.Image)
        Me.TechJobsBindingNavigatorSaveItem.Name = "TechJobsBindingNavigatorSaveItem"
        Me.TechJobsBindingNavigatorSaveItem.Size = New System.Drawing.Size(23, 22)
        Me.TechJobsBindingNavigatorSaveItem.Text = "Save Data"
        '
        'txtPlacement
        '
        Me.txtPlacement.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TechJobsBindingSource, "Placement", True))
        Me.txtPlacement.Location = New System.Drawing.Point(344, 88)
        Me.txtPlacement.Name = "txtPlacement"
        Me.txtPlacement.Size = New System.Drawing.Size(40, 20)
        Me.txtPlacement.TabIndex = 9
        '
        'Job_NameLabel
        '
        Job_NameLabel.AutoSize = True
        Job_NameLabel.Location = New System.Drawing.Point(561, 153)
        Job_NameLabel.Name = "Job_NameLabel"
        Job_NameLabel.Size = New System.Drawing.Size(58, 13)
        Job_NameLabel.TabIndex = 9
        Job_NameLabel.Text = "Job Name:"
        '
        'Median_SalaryLabel
        '
        Median_SalaryLabel.AutoSize = True
        Median_SalaryLabel.Location = New System.Drawing.Point(589, 193)
        Median_SalaryLabel.Name = "Median_SalaryLabel"
        Median_SalaryLabel.Size = New System.Drawing.Size(77, 13)
        Median_SalaryLabel.TabIndex = 10
        Median_SalaryLabel.Text = "Median Salary:"
        '
        'txtMedianSalary
        '
        Me.txtMedianSalary.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TechJobsBindingSource, "Median Salary", True))
        Me.txtMedianSalary.Location = New System.Drawing.Point(374, 198)
        Me.txtMedianSalary.Name = "txtMedianSalary"
        Me.txtMedianSalary.Size = New System.Drawing.Size(100, 20)
        Me.txtMedianSalary.TabIndex = 11
        '
        'Job_NameLabel1
        '
        Job_NameLabel1.AutoSize = True
        Job_NameLabel1.Location = New System.Drawing.Point(542, 151)
        Job_NameLabel1.Name = "Job_NameLabel1"
        Job_NameLabel1.Size = New System.Drawing.Size(58, 13)
        Job_NameLabel1.TabIndex = 11
        Job_NameLabel1.Text = "Job Name:"
        '
        'cboJobName
        '
        Me.cboJobName.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TechJobsBindingSource, "Job Name", True))
        Me.cboJobName.DataSource = Me.TechJobsBindingSource
        Me.cboJobName.DisplayMember = "Job Name"
        Me.cboJobName.FormattingEnabled = True
        Me.cboJobName.Location = New System.Drawing.Point(342, 144)
        Me.cboJobName.Name = "cboJobName"
        Me.cboJobName.Size = New System.Drawing.Size(194, 21)
        Me.cboJobName.TabIndex = 12
        Me.cboJobName.ValueMember = "Job Name"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Black
        Me.ClientSize = New System.Drawing.Size(747, 266)
        Me.Controls.Add(Job_NameLabel1)
        Me.Controls.Add(Me.cboJobName)
        Me.Controls.Add(Median_SalaryLabel)
        Me.Controls.Add(Me.txtMedianSalary)
        Me.Controls.Add(Job_NameLabel)
        Me.Controls.Add(Me.txtPlacement)
        Me.Controls.Add(Me.TechJobsBindingNavigator)
        Me.Controls.Add(Me.lblMedianSalary)
        Me.Controls.Add(Me.lblJobName)
        Me.Controls.Add(Me.lblPlacement)
        Me.Controls.Add(Me.lblHeading)
        Me.Controls.Add(Me.picJobs)
        Me.Name = "Form1"
        Me.Text = "Top Ten Technology Jobs"
        CType(Me.picJobs, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TechJobsDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TechJobsBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TechJobsBindingNavigator, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TechJobsBindingNavigator.ResumeLayout(False)
        Me.TechJobsBindingNavigator.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents picJobs As PictureBox
    Friend WithEvents lblHeading As Label
    Friend WithEvents lblPlacement As Label
    Friend WithEvents lblJobName As Label
    Friend WithEvents lblMedianSalary As Label
    Friend WithEvents TechJobsDataSet As TechJobsDataSet
    Friend WithEvents TechJobsBindingSource As BindingSource
    Friend WithEvents TechJobsTableAdapter As TechJobsDataSetTableAdapters.TechJobsTableAdapter
    Friend WithEvents TableAdapterManager As TechJobsDataSetTableAdapters.TableAdapterManager
    Friend WithEvents TechJobsBindingNavigator As BindingNavigator
    Friend WithEvents BindingNavigatorAddNewItem As ToolStripButton
    Friend WithEvents BindingNavigatorCountItem As ToolStripLabel
    Friend WithEvents BindingNavigatorDeleteItem As ToolStripButton
    Friend WithEvents BindingNavigatorMoveFirstItem As ToolStripButton
    Friend WithEvents BindingNavigatorMovePreviousItem As ToolStripButton
    Friend WithEvents BindingNavigatorSeparator As ToolStripSeparator
    Friend WithEvents BindingNavigatorPositionItem As ToolStripTextBox
    Friend WithEvents BindingNavigatorSeparator1 As ToolStripSeparator
    Friend WithEvents BindingNavigatorMoveNextItem As ToolStripButton
    Friend WithEvents BindingNavigatorMoveLastItem As ToolStripButton
    Friend WithEvents BindingNavigatorSeparator2 As ToolStripSeparator
    Friend WithEvents TechJobsBindingNavigatorSaveItem As ToolStripButton
    Friend WithEvents txtPlacement As TextBox
    Friend WithEvents txtMedianSalary As TextBox
    Friend WithEvents cboJobName As ComboBox
End Class

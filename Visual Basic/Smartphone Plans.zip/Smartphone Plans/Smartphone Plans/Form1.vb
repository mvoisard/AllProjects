﻿' Program Name: Smartphone Plans
' Author:       Max Voisard
' Date:         November 7, 2016
' Purpose:      Allows the user to select from two smartphone specials plans, request
'               request the number of gigabytes used in the data plan, and compute
'               the cost of the smartphone usage bill.

Option Strict On

Public Class Form1

    ' Class variables

    Private Sub cboDataPlan_SelectIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboDataPlan.SelectedIndexChanged, cboDataPlan.SelectedIndexChanged
        ' This event handler allows the user to enter the data plan choice
        Dim decPlanChoice As Decimal

        decPlanChoice = cboDataPlan.SelectedIndex

        lblDataUsage.Visible = True
        txtDataUsage.Visible = True
        btnComputeBill.Visible = True
        btnClear.Visible = True
        lblMonthlyCost.Visible = True
        ' Clear the labels
        lblDataUsage.Text = ""
        lblMonthlyCost.Text = ""
        ' Set focus on number in usage text box
        txtDataUsage.Focus()
    End Sub

    Private Sub btnComputeBill_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnComputeBill.Click
        ' This button event handler determines the cost of the data plan.

        Dim intGigabytesUsed As Integer
        Dim blnNumberInGigabytesIsValid As Boolean = False
        Dim blnDataPlanIsSelected As Boolean = False
        Dim decPlanChoice As Decimal
        Dim decTotalCost As Decimal
        Dim intDataUsage As Integer

        ' Have an If statement to determine validity of user's numerical input
        If (blnNumberInGigabytesIsValid And blnDataPlanIsSelected) Then
            intGigabytesUsed = Convert.ToInt32(txtDataUsage.Text)
            decPlanChoice = cboDataPlan.SelectedIndex
            Select Case decPlanChoice
                Case 0
                    decTotalCost = BasicPlanFindCost(intDataUsage)
                Case 1
                    decTotalCost = DeluxePlanFindCost(intDataUsage)
                    ' Calculate and display total cost.
            End Select
            lblMonthlyCost.Text = decTotalCost.ToString("C") & " per month"
        End If
    End Sub

    Private Function ValidateDataUsage() As Boolean
        ' This function validates the value entered for data usage.

        Dim intGigabytesUsed As Integer
        Dim blnValidityCheck As Boolean = False
        Dim strNumberInDataUsage As String = "Please enter a positive number: "
        Dim strMessageBoxTitle As String = "Error"

        Try
            intGigabytesUsed = Convert.ToInt32(txtDataUsage.Text)
            If intGigabytesUsed < 0 Then
                MsgBox(strNumberInDataUsage, , strMessageBoxTitle)
            End If
        Catch Exception As FormatException
            MsgBox(strNumberInDataUsage, , strMessageBoxTitle)
            txtDataUsage.Focus()
            txtDataUsage.Clear()
        Catch Exception As OverflowException
            MsgBox(strNumberInDataUsage, , strMessageBoxTitle)
            txtDataUsage.Focus()
            txtDataUsage.Clear()
        Catch Exception As SystemException
            MsgBox(strNumberInDataUsage, , strMessageBoxTitle)
            txtDataUsage.Focus()
            txtDataUsage.Clear()
        End Try

        Return blnValidityCheck

    End Function

    Private Function BasicPlanFindCost(ByVal intDataUsage As Integer) As Decimal
        ' This function calculates the cost of the basic data plan

        Dim intDataCost As Integer = 4
        Dim decFinalCost As Decimal
        Dim decBasicPlan As Decimal = 29.99D
        Dim decTotalCost As Decimal

        decTotalCost = intDataCost * intDataUsage
        decFinalCost = decTotalCost + decBasicPlan
        Return decFinalCost

    End Function

    Private Function DeluxePlanFindCost(ByVal intDataUsage As Integer) As Decimal
        ' This function calculates the cost of the basic data plan

        Dim intDataCost As Integer = 1
        Dim decFinalCost As Decimal
        Dim decDeluxePlan As Decimal = 39.99D
        Dim decTotalCost As Decimal

        decTotalCost = intDataCost * intDataUsage
        decFinalCost = decTotalCost + decDeluxePlan
        Return decFinalCost

    End Function

    Private Sub btnClear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClear.Click
        ' This event handler clears the form and resets the form for use when the user hits the Clear Form button.

        cboDataPlan.Text = "Select Monthly Smartphone Data Plan"
        txtDataUsage.Clear()
        lblMonthlyCost.Text = ""
        lblDataUsage.Text = ""
        btnComputeBill.Visible = False
        btnClear.Visible = False
        lblDataUsage.Visible = False
        lblMonthlyCost.Visible = False
        txtDataUsage.Visible = False

    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' Hold the splash screen for 4 seconds.

        Threading.Thread.Sleep(4000)
    End Sub

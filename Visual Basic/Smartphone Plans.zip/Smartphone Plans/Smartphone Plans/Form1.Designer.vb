﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.picSmartphone = New System.Windows.Forms.PictureBox()
        Me.lblHeading = New System.Windows.Forms.Label()
        Me.cboDataPlan = New System.Windows.Forms.ComboBox()
        Me.lblDataUsage = New System.Windows.Forms.Label()
        Me.txtDataUsage = New System.Windows.Forms.TextBox()
        Me.btnComputeBill = New System.Windows.Forms.Button()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.lblMonthlyCost = New System.Windows.Forms.Label()
        CType(Me.picSmartphone, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'picSmartphone
        '
        Me.picSmartphone.Image = Global.Smartphone_Plans.My.Resources.Resources.Smartphone
        Me.picSmartphone.Location = New System.Drawing.Point(2, 2)
        Me.picSmartphone.Name = "picSmartphone"
        Me.picSmartphone.Size = New System.Drawing.Size(142, 238)
        Me.picSmartphone.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picSmartphone.TabIndex = 0
        Me.picSmartphone.TabStop = False
        '
        'lblHeading
        '
        Me.lblHeading.AutoSize = True
        Me.lblHeading.BackColor = System.Drawing.Color.Black
        Me.lblHeading.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblHeading.ForeColor = System.Drawing.Color.Transparent
        Me.lblHeading.Location = New System.Drawing.Point(183, 9)
        Me.lblHeading.Name = "lblHeading"
        Me.lblHeading.Size = New System.Drawing.Size(294, 24)
        Me.lblHeading.TabIndex = 1
        Me.lblHeading.Text = "Select a Smartphone Plan Special"
        '
        'cboDataPlan
        '
        Me.cboDataPlan.FormattingEnabled = True
        Me.cboDataPlan.Items.AddRange(New Object() {"Basic Plan: $29 a month plus $4 per GB of data", "Deluxe Plan: $39 a month plus $1 per GB of data"})
        Me.cboDataPlan.Location = New System.Drawing.Point(187, 45)
        Me.cboDataPlan.Name = "cboDataPlan"
        Me.cboDataPlan.Size = New System.Drawing.Size(284, 21)
        Me.cboDataPlan.TabIndex = 2
        Me.cboDataPlan.Text = "Select Monthly Smartphone Data Plan:"
        '
        'lblDataUsage
        '
        Me.lblDataUsage.AutoSize = True
        Me.lblDataUsage.BackColor = System.Drawing.Color.LightGray
        Me.lblDataUsage.Location = New System.Drawing.Point(214, 96)
        Me.lblDataUsage.Name = "lblDataUsage"
        Me.lblDataUsage.Size = New System.Drawing.Size(171, 13)
        Me.lblDataUsage.TabIndex = 3
        Me.lblDataUsage.Text = "Data Usage - Number of GB Used:"
        Me.lblDataUsage.Visible = False
        '
        'txtDataUsage
        '
        Me.txtDataUsage.Location = New System.Drawing.Point(391, 93)
        Me.txtDataUsage.Name = "txtDataUsage"
        Me.txtDataUsage.Size = New System.Drawing.Size(29, 20)
        Me.txtDataUsage.TabIndex = 4
        Me.txtDataUsage.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.txtDataUsage.Visible = False
        '
        'btnComputeBill
        '
        Me.btnComputeBill.BackColor = System.Drawing.Color.Black
        Me.btnComputeBill.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btnComputeBill.Location = New System.Drawing.Point(276, 127)
        Me.btnComputeBill.Name = "btnComputeBill"
        Me.btnComputeBill.Size = New System.Drawing.Size(109, 27)
        Me.btnComputeBill.TabIndex = 5
        Me.btnComputeBill.Text = "Compute Total Bill"
        Me.btnComputeBill.UseVisualStyleBackColor = False
        Me.btnComputeBill.Visible = False
        '
        'btnClear
        '
        Me.btnClear.BackColor = System.Drawing.Color.Black
        Me.btnClear.ForeColor = System.Drawing.Color.White
        Me.btnClear.Location = New System.Drawing.Point(276, 169)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(110, 27)
        Me.btnClear.TabIndex = 6
        Me.btnClear.Text = "Clear Form"
        Me.btnClear.UseVisualStyleBackColor = False
        Me.btnClear.Visible = False
        '
        'lblMonthlyCost
        '
        Me.lblMonthlyCost.AutoSize = True
        Me.lblMonthlyCost.BackColor = System.Drawing.Color.Black
        Me.lblMonthlyCost.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblMonthlyCost.ForeColor = System.Drawing.Color.White
        Me.lblMonthlyCost.Location = New System.Drawing.Point(273, 210)
        Me.lblMonthlyCost.Name = "lblMonthlyCost"
        Me.lblMonthlyCost.Size = New System.Drawing.Size(94, 13)
        Me.lblMonthlyCost.TabIndex = 7
        Me.lblMonthlyCost.Text = "$XX.XX per month"
        Me.lblMonthlyCost.Visible = False
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(497, 237)
        Me.Controls.Add(Me.lblMonthlyCost)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.btnComputeBill)
        Me.Controls.Add(Me.txtDataUsage)
        Me.Controls.Add(Me.lblDataUsage)
        Me.Controls.Add(Me.cboDataPlan)
        Me.Controls.Add(Me.lblHeading)
        Me.Controls.Add(Me.picSmartphone)
        Me.Name = "Form1"
        Me.Text = "Smartphone Plan Specials"
        CType(Me.picSmartphone, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents picSmartphone As PictureBox
    Friend WithEvents lblHeading As Label
    Friend WithEvents cboDataPlan As ComboBox
    Friend WithEvents lblDataUsage As Label
    Friend WithEvents txtDataUsage As TextBox
    Friend WithEvents btnComputeBill As Button
    Friend WithEvents btnClear As Button
    Friend WithEvents lblMonthlyCost As Label
End Class

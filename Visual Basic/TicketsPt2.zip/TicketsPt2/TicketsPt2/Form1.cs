﻿// Name:        Max Voisard
// Class:       Adv Program with C# CIT223S
// Date:        4/25/17
// Assignment:  Chapter 12 Programming Challenge

using System;
using System.Windows.Forms;
using PlaysNamespace;                       // Importing PlaysNamespace so class can be used to instantiate object
using MusicalsNamespace;                    // Importing MusicalsNamespace so class can be used to instantiate object
using HomeBasketballGamesNamespace;         // Importing HomeBasketballGamesNamespace so class can be used to instantiate object

namespace TicketsPt2
{
    public partial class Form1 : Form                    // Public partial class with colon to extend Form to Form1
    {
        private Plays aPlay;                             // Private object variable of Plays class
        private Musicals aMusical;                       // Private object variable of Musicals class
        private HomeBasketballGames aBasketball;         // Private object variable of HomeBasketballGames class

        public Form1()                      // Default constructor
        {
            InitializeComponent();          // Initializing the controls, like labels and buttons
        }

        private void btnProcessRequest_Click(object sender, EventArgs e)   // Event-handling method that starts when button is clicked
        {
            string theEvent = Convert.ToString(cboEvent.SelectedItem);     // Setting SelectedItem property converted into string to a string variable for event name
            char row = Convert.ToChar(cboRow.SelectedItem);                // Setting SelectedItem property converted into char to a char variable for row letter
            int seat = Convert.ToInt32(cboSeat.SelectedItem);              // Setting SelectedItem property converted into integer to an integer variable for seat number
            double cost = Convert.ToDouble(cboTicketPrice.SelectedItem);   // Setting SelectedItem property converted into double to a double variable for cost
            int actors = 18;                                               // Integer variable for number of actors
            string musicStyle = "Opera/Orchestra";                         // String variable for music style
            string opponentTeam = "Wright State Raiders";                  // String variable for opponent team
            if (cboEvent.SelectedIndex == 0)                               // If SelectedIndex property of comboBox for events is 0, it is "Miracle on 34th Street"
            {
                aPlay = new Plays(actors, theEvent, row, seat, cost);      // Initializing subclass with values of variables
                MessageBox.Show(aPlay.ToString());                         // Displaying Plays class's overriden ToString() method on a MessageBox
            }

            else if (cboEvent.SelectedIndex == 1)                                   // If SelectedIndex property of comboBox for events is 1, it is "Beethoven's 9th Symphony"
            {
                aMusical = new Musicals(musicStyle, theEvent, row, seat, cost);     // Initializing subclass with values of variables
                MessageBox.Show(aMusical.ToString());                               // Displaying Musicals class's overriden ToString() method on a MessageBox
            }

            else if (cboEvent.SelectedIndex == 2)                                                // If SelectedIndex property of comboBox for events is 2, it is "Edison Chargers basketball" 
            {
                aBasketball = new HomeBasketballGames(opponentTeam, theEvent, row, seat, cost);  // Initializing subclass with values of variables
                MessageBox.Show(aBasketball.ToString());                                         // Displaying HomeBasketballGames class's overriden ToString() method on a MessageBox
            }
        }
    }
}
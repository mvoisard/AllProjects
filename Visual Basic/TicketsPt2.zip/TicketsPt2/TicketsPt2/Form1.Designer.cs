﻿namespace TicketsPt2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblQuestion = new System.Windows.Forms.Label();
            this.cboEvent = new System.Windows.Forms.ComboBox();
            this.lblRow = new System.Windows.Forms.Label();
            this.lblSeat = new System.Windows.Forms.Label();
            this.cboRow = new System.Windows.Forms.ComboBox();
            this.cboSeat = new System.Windows.Forms.ComboBox();
            this.lblTicketPrice = new System.Windows.Forms.Label();
            this.cboTicketPrice = new System.Windows.Forms.ComboBox();
            this.btnProcessRequest = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblQuestion
            // 
            this.lblQuestion.AutoSize = true;
            this.lblQuestion.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQuestion.Location = new System.Drawing.Point(102, 20);
            this.lblQuestion.Name = "lblQuestion";
            this.lblQuestion.Size = new System.Drawing.Size(257, 16);
            this.lblQuestion.TabIndex = 0;
            this.lblQuestion.Text = "What event will you purchase tickets from?";
            // 
            // cboEvent
            // 
            this.cboEvent.FormattingEnabled = true;
            this.cboEvent.Items.AddRange(new object[] {
            "Miracle on 34th Street",
            "Beethoven\'s 9th Symphony",
            "Edison Chargers basketball"});
            this.cboEvent.Location = new System.Drawing.Point(151, 57);
            this.cboEvent.Name = "cboEvent";
            this.cboEvent.Size = new System.Drawing.Size(159, 21);
            this.cboEvent.TabIndex = 1;
            // 
            // lblRow
            // 
            this.lblRow.AutoSize = true;
            this.lblRow.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRow.Location = new System.Drawing.Point(145, 104);
            this.lblRow.Name = "lblRow";
            this.lblRow.Size = new System.Drawing.Size(38, 16);
            this.lblRow.TabIndex = 2;
            this.lblRow.Text = "Row:";
            // 
            // lblSeat
            // 
            this.lblSeat.AutoSize = true;
            this.lblSeat.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSeat.Location = new System.Drawing.Point(282, 104);
            this.lblSeat.Name = "lblSeat";
            this.lblSeat.Size = new System.Drawing.Size(49, 16);
            this.lblSeat.TabIndex = 3;
            this.lblSeat.Text = "Seat #:";
            // 
            // cboRow
            // 
            this.cboRow.FormattingEnabled = true;
            this.cboRow.Items.AddRange(new object[] {
            "A",
            "B",
            "C",
            "D",
            "E",
            "F",
            "G",
            "H",
            "I",
            "J",
            "K",
            "L",
            "M",
            "N",
            "O",
            "P",
            "Q",
            "R",
            "S",
            "T",
            "U",
            "V",
            "W",
            "X",
            "Y",
            "Z"});
            this.cboRow.Location = new System.Drawing.Point(97, 130);
            this.cboRow.Name = "cboRow";
            this.cboRow.Size = new System.Drawing.Size(121, 21);
            this.cboRow.TabIndex = 4;
            // 
            // cboSeat
            // 
            this.cboSeat.FormattingEnabled = true;
            this.cboSeat.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15"});
            this.cboSeat.Location = new System.Drawing.Point(243, 130);
            this.cboSeat.Name = "cboSeat";
            this.cboSeat.Size = new System.Drawing.Size(121, 21);
            this.cboSeat.TabIndex = 5;
            // 
            // lblTicketPrice
            // 
            this.lblTicketPrice.AutoSize = true;
            this.lblTicketPrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTicketPrice.Location = new System.Drawing.Point(190, 176);
            this.lblTicketPrice.Name = "lblTicketPrice";
            this.lblTicketPrice.Size = new System.Drawing.Size(81, 16);
            this.lblTicketPrice.TabIndex = 6;
            this.lblTicketPrice.Text = "Ticket price:";
            // 
            // cboTicketPrice
            // 
            this.cboTicketPrice.FormattingEnabled = true;
            this.cboTicketPrice.Items.AddRange(new object[] {
            "10.00",
            "20.00",
            "30.00",
            "40.00",
            "50.00",
            "60.00",
            "70.00",
            "80.00",
            "90.00",
            "100.00"});
            this.cboTicketPrice.Location = new System.Drawing.Point(170, 208);
            this.cboTicketPrice.Name = "cboTicketPrice";
            this.cboTicketPrice.Size = new System.Drawing.Size(121, 21);
            this.cboTicketPrice.TabIndex = 7;
            // 
            // btnProcessRequest
            // 
            this.btnProcessRequest.Location = new System.Drawing.Point(193, 245);
            this.btnProcessRequest.Name = "btnProcessRequest";
            this.btnProcessRequest.Size = new System.Drawing.Size(75, 40);
            this.btnProcessRequest.TabIndex = 8;
            this.btnProcessRequest.Text = "Process Request";
            this.btnProcessRequest.UseVisualStyleBackColor = true;
            this.btnProcessRequest.Click += new System.EventHandler(this.btnProcessRequest_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.ForestGreen;
            this.ClientSize = new System.Drawing.Size(461, 306);
            this.Controls.Add(this.btnProcessRequest);
            this.Controls.Add(this.cboTicketPrice);
            this.Controls.Add(this.lblTicketPrice);
            this.Controls.Add(this.cboSeat);
            this.Controls.Add(this.cboRow);
            this.Controls.Add(this.lblSeat);
            this.Controls.Add(this.lblRow);
            this.Controls.Add(this.cboEvent);
            this.Controls.Add(this.lblQuestion);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblQuestion;
        private System.Windows.Forms.ComboBox cboEvent;
        private System.Windows.Forms.Label lblRow;
        private System.Windows.Forms.Label lblSeat;
        private System.Windows.Forms.ComboBox cboRow;
        private System.Windows.Forms.ComboBox cboSeat;
        private System.Windows.Forms.Label lblTicketPrice;
        private System.Windows.Forms.ComboBox cboTicketPrice;
        private System.Windows.Forms.Button btnProcessRequest;
    }
}


﻿using System;
using TicketsNamespace;              // Importing TicketsNamespace so base class can be accessed

namespace MusicalsNamespace
{
    public class Musicals : Ticket   // Making Musicals a subclass of the base class Ticket
    {
        private string musicStyle;   // Declaring private string variable for music style

        public Musicals()    // Default constructor calling the base class
            :base()
        {
        }

        public Musicals(string genre, string theEvent, char row, int seat, double cost)   // Constructor with specified arguments
            :base(theEvent, row, seat, cost)   // Calling the base class's variables
        {
            musicStyle = genre;   // Setting class's private variable equal to argument
        }

        public string MusicStyle        // Method for music style
        {
            get
            {
                return musicStyle;      // Return statement for music style in accessor method
            }
            set
            {
                musicStyle = value;     // Assigning value equal to music style variable in mutator method
            }
        }
        public override string ToString()   // Method to override the base class's ToString() method
        {
            return base.ToString() + "\nMusic style: " + musicStyle;  // Adding information to base class ToString() method
        }
    }
}
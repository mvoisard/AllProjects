﻿using System;
using TicketsNamespace;                             // Importing TicketsNamespace so base class can be accessed

namespace HomeBasketballGamesNamespace
{
        public class HomeBasketballGames : Ticket   // Making HomeBasketballGames a subclass of the base class Ticket
        {
            private string opponentTeam;   // Declaring private string variable for basketball opponent team

            public HomeBasketballGames()   // Default constructor calling the base class
                :base()
            {
            }

            public HomeBasketballGames(string opponent, string eventName, char row, int seat, double cost)   // Constructor with arguments
                :base(eventName, row, seat, cost)   // Calling base class's variables
            {
                opponentTeam = opponent;  // Setting class's private variable equal to argument 
            }

            public string OpponentTeam      // String method for opponent team
            {
                get
                {
                    return opponentTeam;    // Getter method which returns the variable
                }
                set
                {
                    opponentTeam = value;   // Setter method which is set equal to value
                }
            }

            public override string ToString()   // ToString() method to override base class ToString() method
            {
                return base.ToString() + "\nOpponent team: " + opponentTeam;  // Adding opponent team to base class method
            }

    }
}

﻿using System;
using TicketsNamespace;               // Importing TicketsNamespace so base class can be accessed

namespace PlaysNamespace
{
    public class Plays : Ticket       // Making Plays a subclass of the base class Ticket
    {
        private int numberOfActors;   // Private integer variable for number of actors in subclass

        public Plays()    // Default constructor calling the base class
            :base()
        {
        }

        public Plays(int actors, string eventName, char row, int seat, double cost)  // Constructor with set arguments for Plays
                :base(eventName, row, seat, cost)   // Base class's variables
        {
            numberOfActors = actors;   // Setting equal to argument
        }

        public int NumberOfActors          // Integer method for number of actors
        {
            get
            {
                return numberOfActors;     // Getter method that returns number of actors
            }
            set
            {
                numberOfActors = value;    // Setting equal to value in setter method
            }
        }
        public override string ToString()  // Method to override similar method in base class
        {
            return base.ToString() + "\nNumber of actors: " + numberOfActors;  // Adding number of actors to base class method
        }
    }
}

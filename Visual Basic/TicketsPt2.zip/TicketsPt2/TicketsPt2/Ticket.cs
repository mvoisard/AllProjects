﻿using System;

namespace TicketsNamespace
{
    public abstract class Ticket    // Abstract base class, so it cannot be initialized
    {
        // Declaring private variables to be used throughout class
        private string eventName;
        private char rowLetter;
        private int seatNumber;
        private double admissionCost;

        public Ticket()    // Default constructor
        {
        }
        public Ticket(string theEvent, char row, int seat, double cost)
        {
            // Setting variables equal to variables in the client application which gets the inputs
            eventName = theEvent;
            rowLetter = row;
            seatNumber = seat;
            admissionCost = cost;
        }

        public string EventName              // User-defined constructor
        {
            get
            {
                return eventName;            // Accessor, or getter, returning the string of the event
            }

            set
            {
                eventName = value;           // Mutator, or setter, setting event to a value
            }
        }
        public char Row                      // Char constructor for the rows
        {
            get
            {
                return rowLetter;            // Accessor, or getter, returning the row letter
            }

            set
            {
                rowLetter = value;           // Mutator, or setter, setting row to a value
            }
        }

        public int Seat                      // Integer constructor for seat number
        {
            get
            {
                return seatNumber;           // Accessor, or getter, returning the seat number
            }
            set
            {
                seatNumber = value;          // Mutator, or setter, setting seat to a value
            }
        }

        public double AdmissionCost          // Double constructor for the ticket cost
        {
            get
            {
                return admissionCost;        // Accessor, or getter, returning the double of the cost     
            }

            set
            {
                admissionCost = value;       // Mutator, or setter, setting cost to a value
            }
        }

        public override string ToString()
        {
            // Displaying the results of inputs and calculations back to the user through return statement with the variable values
            return "Event: " + eventName + "\nRow: " + rowLetter +
                "\nSeat: " + seatNumber + "\nTotal Cost: $" + admissionCost;
        }
    }
}

